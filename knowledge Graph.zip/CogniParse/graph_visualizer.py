import networkx as nx
from pyvis.network import Network

def build_knowledge_graph(triplets):
    """
    Constructs a NetworkX directed graph from a list of triplets.
    """
    G = nx.DiGraph()
    for triplet in triplets:
        subject = triplet["subject"]
        relation = triplet["relationship"]
        obj = triplet["object"]
        
        G.add_node(subject, title=subject)
        G.add_node(obj, title=obj)
        G.add_edge(subject, obj, title=relation, label=relation)
        
    return G

def generate_interactive_graph(nx_graph, output_file="graph.html"):
    """
    Takes a NetworkX graph and generates an interactive HTML file using PyVis.
    """
    # Create pyvis network, using CDN resources to avoid local file missing in Streamlit
    net = Network(notebook=False, directed=True, cdn_resources='remote', height="600px", width="100%", bgcolor="#222222", font_color="white")
    
    # Import networkx graph
    net.from_nx(nx_graph)
    
    # Customize the physics layout
    net.repulsion(node_distance=150, spring_length=200)
    
    # Generate and save HTML
    net.save_graph(output_file)
    return output_file
