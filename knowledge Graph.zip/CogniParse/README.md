# 🧠 CogniParse

**The Universal Knowledge Graph Builder that blows minds.**

CogniParse takes complex texts or Wikipedia concepts and automatically transforms them into stunning, interactive Knowledge Graphs. By combining modern NLP (spaCy) and advanced graph visualization (PyVis, NetworkX), it uncovers the hidden relationships in your data.

## 🌟 Why is this mind-blowing?

No matter what industry you are in, unstructured text is everywhere. CogniParse magically structures it for you:
- **Medical/Healthcare**: Input medical journals to instantly see the relationships between drugs, diseases, and side effects.
- **Legal/Finance**: Feed it contracts or SEC filings to map out corporate structures, liabilities, and obligations.
- **Entrepreneurs**: Map out competitive landscapes or supply chains automatically from web scraped text.
- **Education/Research**: Summarize vast amounts of history or scientific concepts into visual, easily digestible nodes.

## 🚀 Features
- **Auto-Extraction**: Utilizes `spaCy` to extract Subject-Verb-Object relationships automatically.
- **Wikipedia Integration**: Just type a topic and get its knowledge graph in seconds.
- **Interactive Visualization**: Zoom, drag, and explore nodes physics-enabled with `PyVis`.
- **Customizable**: Drop in any custom text and watch the graph generate instantly.

## 🛠️ Installation and Setup

1. **Clone the repository** and navigate to the project directory:
   ```bash
   cd CogniParse
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Download the spaCy language model**:
   *(The app handles this automatically, but you can run it manually just in case)*
   ```bash
   python -m spacy download en_core_web_sm
   ```

4. **Run the Streamlit App**:
   ```bash
   streamlit run app.py
   ```

## 📸 Usage
Once the app is running:
1. Open the provided localhost URL in your browser.
2. In the sidebar, choose either **Wikipedia Topic** or **Custom Text**.
3. Enter your topic (e.g., "Artificial Intelligence", "Elon Musk") or paste a document.
4. Click **Fetch & Analyze**.
5. Watch as it extracts entities and generates the interactive graph right in front of you!

---
*Built with ❤️ using Python, Streamlit, spaCy, and NetworkX.*
