import streamlit as App
import streamlit.components.v1 as components
import os

from nlp_engine import extract_entities_and_relationships, fetch_wikipedia_summary
from graph_visualizer import build_knowledge_graph, generate_interactive_graph

App.set_page_config(page_title="CogniParse - Knowledge Graph Builder", layout="wide")

App.title("🧠 CogniParse: Universal Knowledge Graph Builder")
App.markdown("Transform any text or Wikipedia topic into an interactive knowledge graph. Useful for any industry: **Research**, **Legal**, **Medical**, **Business**, etc.")

# Sidebar for inputs
with App.sidebar:
    App.header("Input Source")
    input_type = App.radio("Select input type:", ["Wikipedia Topic", "Custom Text"])
    
    if input_type == "Wikipedia Topic":
        topic = App.text_input("Enter a Wikipedia topic:", "Artificial Intelligence")
        fetch_btn = App.button("Fetch & Analyze")
    else:
        custom_text = App.text_area("Enter your custom text here:")
        fetch_btn = App.button("Analyze Text")

# Main content area
if fetch_btn:
    with App.spinner("Processing..."):
        text_to_process = ""
        
        if input_type == "Wikipedia Topic" and topic:
            App.info(f"Fetching summary for: {topic}")
            text_to_process = fetch_wikipedia_summary(topic)
            if text_to_process.startswith("Ambiguous") or text_to_process.startswith("Page not found") or text_to_process.startswith("An error"):
                App.error(text_to_process)
                text_to_process = ""
            else:
                App.success("Wikipedia content fetched successfully.")
                with App.expander("View Text"):
                    App.write(text_to_process)
        elif input_type == "Custom Text" and custom_text:
            text_to_process = custom_text
        
        if text_to_process:
            App.subheader("Extracting Entities and Relationships")
            triplets = extract_entities_and_relationships(text_to_process)
            
            if not triplets:
                App.warning("Could not extract any meaningful triplets from the text.")
            else:
                App.write(f"Extracted {len(triplets)} relationship(s).")
                with App.expander("View Raw Triplets"):
                    App.dataframe(triplets)
                
                App.subheader("Interactive Knowledge Graph")
                
                # Build graph
                G = build_knowledge_graph(triplets)
                
                # Generate HTML
                html_file = "graph.html"
                generate_interactive_graph(G, html_file)
                
                # Display the HTML in Streamlit
                with open(html_file, "r", encoding="utf-8") as f:
                    html_content = f.read()
                
                components.html(html_content, height=650)
                
                # Cleanup
                if os.path.exists(html_file):
                    os.remove(html_file)

App.markdown("---")
App.markdown("**CogniParse** | Built with Streamlit, spaCy, NetworkX, and PyVis.")
