import spacy
import wikipedia

# Load the spaCy English model
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    import subprocess
    subprocess.run(["python", "-m", "spacy", "download", "en_core_web_sm"])
    nlp = spacy.load("en_core_web_sm")

def extract_entities_and_relationships(text):
    """
    Parses text using spaCy and extracts basic (subject, verb, object) triplets.
    Returns a list of dictionaries.
    """
    doc = nlp(text)
    triplets = []
    
    for sent in doc.sents:
        subject = None
        verb = None
        obj = None
        
        for token in sent:
            # Check for subject
            if token.dep_ in ("nsubj", "nsubjpass"):
                subject = token.text
            # Check for verb (root of the sentence)
            elif token.pos_ == "VERB":
                verb = token.lemma_
            # Check for object
            elif token.dep_ in ("dobj", "pobj", "attr"):
                obj = token.text
                
        if subject and verb and obj:
            triplets.append({
                "subject": subject,
                "relationship": verb,
                "object": obj
            })
            
    return triplets

def fetch_wikipedia_summary(topic, sentences=5):
    """
    Fetches the summary of a topic from Wikipedia.
    """
    try:
        summary = wikipedia.summary(topic, sentences=sentences)
        return summary
    except wikipedia.exceptions.DisambiguationError as e:
        return f"Ambiguous topic. Try one of: {', '.join(e.options[:5])}"
    except wikipedia.exceptions.PageError:
        return "Page not found."
    except Exception as e:
        return f"An error occurred: {str(e)}"
