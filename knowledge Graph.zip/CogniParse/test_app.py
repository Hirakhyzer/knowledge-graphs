from nlp_engine import extract_entities_and_relationships
from graph_visualizer import build_knowledge_graph, generate_interactive_graph
import os

def test_pipeline():
    print("Testing NLP extraction...")
    text = "Apple bought a startup. Google launched a new product. The CEO fired the employee."
    triplets = extract_entities_and_relationships(text)
    assert len(triplets) > 0, "No triplets extracted."
    print("Triplets extracted:", triplets)

    print("Testing Graph generation...")
    G = build_knowledge_graph(triplets)
    assert len(G.nodes) > 0, "Graph has no nodes."
    assert len(G.edges) > 0, "Graph has no edges."

    print("Testing HTML generation...")
    output_file = "test_graph.html"
    generate_interactive_graph(G, output_file)
    assert os.path.exists(output_file), "HTML file was not created."

    print("All tests passed successfully.")
    
    if os.path.exists(output_file):
        os.remove(output_file)

if __name__ == "__main__":
    test_pipeline()
